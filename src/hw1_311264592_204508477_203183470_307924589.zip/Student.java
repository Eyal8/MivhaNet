/**
 * Created by eyal8_000 on 14/04/2018.
 */
public class Student {
  private String ID;
  private String firstName;
  private String lastName;
}
