import java.util.ArrayList;

/**
 * Created by eyal8_000 on 14/04/2018.
 */
public class Course {
  private String courseID;
  private String name;
  private QuestionsPool qp;
}
