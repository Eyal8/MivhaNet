/**
 * Created by eyal8_000 on 14/04/2018.
 */
public class Error {
  private CourseInSemester cis;
}
