/**
 * Created by eyal8_000 on 14/04/2018.
 */
public abstract class User {
  protected String userName;
  protected String firstName;
  protected String lastName;
  protected String ID;
  protected String address;
  protected String phoneNumber;
  protected String email;
}
