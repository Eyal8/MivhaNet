import java.util.ArrayList;

/**
 * Created by eyal8_000 on 14/04/2018.
 */
public class Logger {
   private  ArrayList<Action> actions;
   private ArrayList<Error> errors;
}
