/**
 * Created by eyal8_000 on 14/04/2018.
 */
public class Choice {
  private String content;
  private boolean isTrue;
  private Question q;
}
