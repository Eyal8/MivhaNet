/**
 * Created by eyal8_000 on 14/04/2018.
 */
public abstract class TeachingEmployee extends User {
}
