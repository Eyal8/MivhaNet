import java.util.ArrayList;

/**
 * Created by eyal8_000 on 14/04/2018.
 */
public class Question {
  protected String body;
  protected Difficulty difficultyLevel;
  protected double estimatedTime;
  protected ArrayList<Comment> comments;
  protected ArrayList<Choice> choices;
  protected QuestionsPool qp;
  protected TeachingEmployee te;
}
