import java.util.ArrayList;

/**
 * Created by eyal8_000 on 16/04/2018.
 */
public class CourseInSemester {
  private Course course;
  private Semester semester;
  private ArrayList<Tutor> tutors;
  private ArrayList<Professor> professors;
  private CourseManager manager;
  private Secretariat s;
  private ArrayList<Exam> exams;
  private ArrayList<Action> actions;
  private ArrayList<Error> errors;
}
