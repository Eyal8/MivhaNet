import java.util.ArrayList;
import java.util.Date;

/**
 * Created by eyal8_000 on 14/04/2018.
 */
public class Exam {
  private String courseID;
  private Date data;
  private SemesterType semester;
  private Moed moed;
  private float duration;
  private ArrayList<QuestionInExam> questions;
  private CourseInSemester cis;
}
