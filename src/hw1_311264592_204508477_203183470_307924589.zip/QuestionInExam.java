/**
 * Created by eyal8_000 on 14/04/2018.
 */
public class QuestionInExam extends Question {
  private boolean answeredRight;
  private int score;
  private Exam exam;
}
